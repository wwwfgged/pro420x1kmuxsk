﻿import 'dart:io';
import 'dart:convert';

/// Конфігурація додатку pro420x1kmuxsk v5.0 (Windows)
/// 
/// Ключі запуску:
///   --help        Показати список ключів
///   --test        Увімкнути тестовий режим
///   --linold      Запустити в мобільному (старому) режимі
///
/// Приклад:
///   muzik420_new.exe --test
///   muzik420_new.exe --linold
///   muzik420_new.exe --help

class AppConfig {
  static bool _testMode = false;
  static bool get testMode => _testMode;

  static bool _desktopLayout = true;
  static bool get desktopLayout => _desktopLayout;

  static bool _wallpaperBg = false;
  static bool get wallpaperBg => _wallpaperBg;

  static String? _wallpaperPath;
  static String? get wallpaperPath => _wallpaperPath;

  static String get _cfgPath {
    final appData = Platform.environment['APPDATA'];
    if (appData != null && appData.isNotEmpty) {
      return '$appData\\muzik420\\config.json';
    }
    // Фолбек, якщо APPDATA чомусь недоступний
    final userProfile = Platform.environment['USERPROFILE'] ?? 'C:\\Users\\user';
    return '$userProfile\\AppData\\Roaming\\muzik420\\config.json';
  }

  /// Показати шлях у людському вигляді для екрану "Про додаток"
  static String get cfgPathDisplay => _cfgPath;

  static String get musicDirDisplay {
    final userProfile = Platform.environment['USERPROFILE'] ?? 'C:\\Users\\user';
    return '$userProfile\\Music\\muzik420';
  }

  /// Завантажити конфігурацію + обробити аргументи командного рядка
  static Future<void> load(List<String> args) async {
    // Обробка ключів запуску
    if (args.contains('--help') || args.contains('-help') || args.contains('-h')) {
      _printHelp();
      exit(0);
    }

    // Завантажуємо збережені налаштування
    try {
      final file = File(_cfgPath);
      if (await file.exists()) {
        final json = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
        _desktopLayout = json['desktopLayout'] as bool? ?? true;
        _wallpaperBg = json['wallpaperBg'] as bool? ?? false;
        // testMode НЕ зберігаємо - тільки через ключ
      }
    } catch (e) {
      print('[AppConfig] Load error: $e');
    }

    // Ключі перезаписують збережені налаштування
    if (args.contains('--test') || args.contains('-test')) {
      _testMode = true;
      print('[AppConfig] ⚠️ ТЕСТОВИЙ РЕЖИМ (--test)');
    }

    if (args.contains('--linold') || args.contains('-linold')) {
      _desktopLayout = false;
      print('[AppConfig] 📱 МОБІЛЬНИЙ РЕЖИМ (--linold)');
    }

    if (_wallpaperBg) await _loadWallpaper();
  }

  static void _printHelp() {
    print('''
╔══════════════════════════════════════════════╗
║        pro420x1kmuxsk v5.0 (Windows)        ║
╚══════════════════════════════════════════════╝

Використання:
  muzik420_new.exe [ключі]

Ключі:
  --help     Показати цю довідку і вийти
  --test     Увімкнути тестовий режим (для розробки)
             Показує додаткову інформацію в UI
  --linold   Запустити в мобільному (старому) режимі
             Вимикає ПК дизайн (sidebar, таблиця)

Приклади:
  muzik420_new.exe
  muzik420_new.exe --test
  muzik420_new.exe --linold
  muzik420_new.exe --test --linold

Налаштування зберігаються в:
  %APPDATA%\\muzik420\\config.json

Музика знаходиться в:
  %USERPROFILE%\\Music\\muzik420\\
''');
  }

  /// Зберегти конфігурацію (без testMode - він тільки через ключ)
  static Future<void> _save() async {
    try {
      final file = File(_cfgPath);
      await file.parent.create(recursive: true);
      await file.writeAsString(jsonEncode({
        'desktopLayout': _desktopLayout,
        'wallpaperBg': _wallpaperBg,
      }));
    } catch (e) {
      print('[AppConfig] Save error: $e');
    }
  }

  /// Перемикачі
  static Future<void> setDesktopLayout(bool value) async {
    _desktopLayout = value;
    await _save();
  }

  static Future<void> setWallpaperBg(bool value) async {
    _wallpaperBg = value;
    if (value) await _loadWallpaper();
    else _wallpaperPath = null;
    await _save();
  }

  /// Завантажити шпалери робочого столу (Windows).
  /// Windows завжди кешує поточні шпалери робочого стола сюди —
  /// не треба ніяких зовнішніх команд (gsettings/magick — то було
  /// з Linux-версії і на Windows не існує).
  static Future<void> _loadWallpaper() async {
    try {
      final appData = Platform.environment['APPDATA'];
      if (appData == null || appData.isEmpty) {
        print('[AppConfig] Wallpaper: APPDATA недоступний');
        return;
      }
      final cached = '$appData\\Microsoft\\Windows\\Themes\\TranscodedWallpaper';
      if (await File(cached).exists()) {
        _wallpaperPath = cached;
        print('[AppConfig] Wallpaper: $_wallpaperPath');
        return;
      }
      print('[AppConfig] Wallpaper: файл кешу шпалер не знайдено');
    } catch (e) {
      print('[AppConfig] Wallpaper error: $e');
    }
  }

  static Future<void> reloadWallpaper() async {
    if (_wallpaperBg) await _loadWallpaper();
  }
}

