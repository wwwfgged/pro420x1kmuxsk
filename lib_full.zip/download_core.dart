import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'models/song.dart';

Future<Directory> getMusicDir() async {
  final home = Platform.environment['USERPROFILE'] ?? Platform.environment['HOME'] ?? '.';
  final dir = Directory('$home\\Music\\muzik420');
  if (!await dir.exists()) await dir.create(recursive: true);
  return dir;
}

typedef ProgressCb = void Function(String status, double progress);

/// Завантажити відео/аудіо з YouTube за посиланням. Повертає локальний
/// шлях до збереженого файлу, або null при помилці.
/// Використовується і UI-завантажувачем, і відновленням з Google Drive.
Future<String?> downloadYoutubeVideo(String url, {ProgressCb? onProgress}) async {
  final yt = YoutubeExplode();
  try {
    final base = await getMusicDir();
    onProgress?.call('Підключаюсь...', 0.05);
    final video = await yt.videos.get(url);
    final safe = video.title.replaceAll(RegExp(r'[<>:"/\\|?*#]'), '').trim();
    onProgress?.call('Знайдено: ${video.title}', 0.15);

    Directory saveDir = base;
    try {
      final t = await http.get(Uri.parse(video.thumbnails.highResUrl)).timeout(const Duration(seconds: 8));
      if (t.statusCode == 200) {
        final songDir = Directory('${base.path}\\$safe');
        if (!await songDir.exists()) await songDir.create(recursive: true);
        await File('${songDir.path}\\cover.jpg').writeAsBytes(t.bodyBytes);
        saveDir = songDir;
      }
    } catch (_) {}

    onProgress?.call('Отримую стріми...', 0.25);
    StreamManifest manifest;
    try {
      manifest = await yt.videos.streams.getManifest(video.id,
        ytClients: [YoutubeApiClient.androidVr, YoutubeApiClient.safari, YoutubeApiClient.ios]);
    } catch (_) { manifest = await yt.videos.streams.getManifest(video.id); }

    StreamInfo? info;
    if (manifest.muxed.isNotEmpty) {
      info = manifest.muxed.sortByVideoQuality().first;
    } else if (manifest.audioOnly.isNotEmpty) {
      info = manifest.audioOnly.withHighestBitrate();
    } else {
      onProgress?.call('❌ Немає стрімів', 0);
      return null;
    }

    final filePath = '${saveDir.path}\\$safe.mp4';
    final total = info.size.totalBytes;
    var recv = 0;
    final sink = File(filePath).openWrite();
    await for (final chunk in yt.videos.streams.get(info)) {
      sink.add(chunk); recv += chunk.length;
      final p = total > 0 ? 0.30 + (recv / total) * 0.65 : (recv / (30*1024*1024)).clamp(0.30, 0.95);
      onProgress?.call('Завантажую... ${(recv/1024/1024).toStringAsFixed(1)} MB', p);
    }
    await sink.flush(); await sink.close();

    final size = await File(filePath).length();
    if (size < 10000) {
      try { await File(filePath).delete(); } catch (_) {}
      onProgress?.call('❌ Порожній файл', 0);
      return null;
    }

    try {
      final sourcesFile = File('${base.path}\\${SourceStore.fileNameOf()}');
      await SourceStore.set(sourcesFile, filePath, 'https://youtube.com/watch?v=${video.id.value}');
    } catch (_) {}

    onProgress?.call('✅ Завантажено!', 1.0);
    return filePath;
  } catch (e) {
    onProgress?.call('❌ Помилка: $e', 0);
    return null;
  } finally {
    yt.close();
  }
}

/// Завантажити відео/музику з TikTok за посиланням. Повертає локальний
/// шлях до збереженого файлу, або null при помилці.
Future<String?> downloadTikTokVideo(String url, {ProgressCb? onProgress}) async {
  try {
    final base = await getMusicDir();
    onProgress?.call('Підключаюсь до TikTok...', 0.05);
    final r = await http.post(Uri.parse('https://www.tikwm.com/api/'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Mozilla/5.0 (Linux; Android 13)'},
      body: 'url=${Uri.encodeComponent(url)}&count=12&cursor=0&web=1&hd=1',
    ).timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('tikwm статус ${r.statusCode}');
    final d = jsonDecode(r.body);
    if (d['code'] != 0) throw Exception('tikwm: ${d['msg']}');
    final data = d['data'] as Map<String, dynamic>;
    final title = (data['title'] as String? ?? 'TikTok').replaceAll(RegExp(r'[<>:"/\\|?*#]'), '').trim();
    final safe = title.length > 50 ? title.substring(0, 50) : title;
    final dlUrl = data['music_info']?['play'] as String? ?? data['wmplay'] as String? ?? data['play'] as String?;
    final cover = data['cover'] as String?;

    Directory saveDir = base;
    if (cover != null) {
      try {
        final t = await http.get(Uri.parse(cover)).timeout(const Duration(seconds: 8));
        if (t.statusCode == 200) {
          final songDir = Directory('${base.path}\\$safe');
          if (!await songDir.exists()) await songDir.create(recursive: true);
          await File('${songDir.path}\\cover.jpg').writeAsBytes(t.bodyBytes);
          saveDir = songDir;
        }
      } catch (_) {}
    }
    if (dlUrl == null) throw Exception('Немає посилання');
    onProgress?.call('Знайдено: $title', 0.30);
    final ext = dlUrl.contains('.mp3') ? 'mp3' : 'mp4';
    final req = http.Request('GET', Uri.parse(dlUrl));
    req.headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 13)';
    req.headers['Referer'] = 'https://www.tiktok.com/';
    final resp = await req.send().timeout(const Duration(minutes: 10));
    final totalB = resp.contentLength ?? 0;
    var recv = 0;
    final filePath = '${saveDir.path}\\$safe.$ext';
    final sink = File(filePath).openWrite();
    await for (final chunk in resp.stream) {
      sink.add(chunk); recv += chunk.length;
      final p = totalB > 0 ? 0.30 + (recv / totalB) * 0.70 : (recv / (20*1024*1024)).clamp(0.30, 0.95);
      onProgress?.call('Завантажую... ${(recv/1024/1024).toStringAsFixed(1)} MB', p);
    }
    await sink.flush(); await sink.close();
    final size = await File(filePath).length();
    if (size < 5000) throw Exception('Файл порожній');

    try {
      final sourcesFile = File('${base.path}\\${SourceStore.fileNameOf()}');
      await SourceStore.set(sourcesFile, filePath, url);
    } catch (_) {}

    onProgress?.call('✅ Завантажено!', 1.0);
    return filePath;
  } catch (e) {
    onProgress?.call('❌ Помилка: $e', 0);
    return null;
  }
}

/// Завантажити за посиланням, автоматично визначивши YouTube чи TikTok.
Future<String?> downloadFromUrl(String url, {ProgressCb? onProgress}) async {
  final lower = url.toLowerCase();
  if (lower.contains('tiktok.com')) {
    return downloadTikTokVideo(url, onProgress: onProgress);
  }
  return downloadYoutubeVideo(url, onProgress: onProgress);
}
